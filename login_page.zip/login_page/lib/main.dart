import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'constant.dart';
import 'roundbutton.dart';
import 'package:social_media_buttons/social_media_buttons.dart';

void main() => runApp(FoodToGoLoginPage());

class FoodToGoLoginPage extends StatelessWidget {
  FocusNode myFocusNode = new FocusNode();
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.green,
        body: SafeArea(
          child: Column(
            children: <Widget>[
              Center(
                child: Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: Container(
                    child: Image.asset(
                      'images/flogo.png',
                      width: 200.0,
                      height: 50.0,
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 30.0,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 20, right: 20),
                child: TextField(
                  onChanged: (value) {},
                  decoration: InputDecoration (
                    filled: true,
                      fillColor: Colors.white,

                      border: OutlineInputBorder(borderRadius:BorderRadius.circular(20)), labelText: 'Email',labelStyle: TextStyle(
                      color: myFocusNode.hasFocus ? Colors.lightGreen : Colors.black
                  ),),
                ),
              ),
              SizedBox(
                height: 20.0,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 20, right: 20),
                child: TextField(
                  onChanged: (value) {},
                  decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.white,
                      
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)), labelText: 'Password',labelStyle: TextStyle(
                      color: myFocusNode.hasFocus ? Colors.lightGreen : Colors.black
                  ),),


                ),
              ),
              SizedBox(
                height: 20.0,
              ),
              RoundedButton(
                colour: Colors.lightGreen,
                title: 'Sign In',
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
              SizedBox(
                height: 5.0,
              ),
              Text(
                'or Sign in with',
                style: TextStyle(
                    color: Colors.white, fontSize: 16.0, fontFamily: 'Russian'),
              ),
              SizedBox(
                height: 10.0,
              ),
              Row(
                children: <Widget>[
                  Expanded(
                    flex: 1,
                    child: SocialMediaButton.google(
                      size: 50.0,
                      color: Colors.white,
                      onTap: () {
                        print('go to google');
                      },
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    child: SocialMediaButton.facebook(
                      size: 50.0,
                      color: Colors.white,
                      onTap: () {
                        print('go to faceboook');
                      },
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    child: FlatButton(
                      onPressed: () {
                        print('go to mobile verification');
                      },
                      child: Icon(
                        Icons.phone_android,
                        size: 50.0,
                        color: Colors.white,
                      ),
                    ),
                  )
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(child: Center(child: Text('Gmail',style: TextStyle (color: Colors.white),))),
                  Expanded(child: Center(child: Text('Facebook',style: TextStyle (color: Colors.white),))),
                  Expanded(child: Center(child: Text('OTP',style: TextStyle (color: Colors.white),)))
                ],
              ),
              Expanded(
                child: Align(
                  alignment: FractionalOffset.bottomCenter,
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Text(
                      ' Click here to Sign up ',
                      style: TextStyle(fontSize: 18.0, color: Colors.white),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
